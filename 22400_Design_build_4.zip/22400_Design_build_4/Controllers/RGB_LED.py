from machine import Pin, PWM

class LED:
    def __init__ (self)-> None:
        self.Red = PWM(Pin(19))
        self.Green = PWM(Pin(16))
        self.Blue = PWM(Pin(18))
        self.red_value = 0
        self.green_value = 0
        self.blue_value = 0

    def turn_off_led(self):
        self.Red.duty(0)
        self.Green.duty(0)
        self.Blue.duty(0)
    
    def turn_on_led(self):
        self.Red.duty(1000)
        self.Green.duty(0)
        self.Blue.duty(1000)
    def get_rgb_values(self):
        # This function should return the current RGB values
        return self.red_value, self.green_value, self.blue_value
