# PinInterrupt = Pin(00, Pin.IN)    # TODO: Def. pin 

# Interrupt = False

# def button_pushed():
#     global Interrupt
#     Interrupt = True

# PinInterrupt.irq(trigger = Pin.IRQ_FALLING | Pin.IRQ_RISING, handler = button_pushed)
